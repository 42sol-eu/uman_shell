# README: modern-shell

TODO: add text 